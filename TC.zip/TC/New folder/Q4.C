#include<stdio.h>
#include<conio.h>
#include<string.h>
 void main()
  {
   int a[10],i=1,ch,j, temp, n , m, max;
   clrscr();
   printf("\n Enter ten elements=");
   for(i=0;i<10;i++)
   scanf("\n%d",&a[i]);

   printf("\n\t\t 1. Ascending Order \n\t\t 2. Descending Order\n\t\t 3. Search \n\t\t 4. Swap\n\t\t 5. Maximum element \n\n\n\t\t Enter Choice :- ");
   scanf("%d",&ch);
   switch(ch)
   {
   case 1:
	    for(j=0;j<10;j++)
	     {
	      for(i=0;i<10;i++)
	       {
		if(a[i]>a[i+1])
		 {
		  temp=a[i];
		  a[i]=a[i+1];
		  a[i+1]=temp;
		 }
	       }
	     }
	    printf("\n\n\t\t The Ascending Order is:-\n");
	    for(i=0;i<10;i++)
	     {
	      printf("\n%d",a[i]);
	     }
	    break;

   case 2: for(j=0;j<10;j++)
	    {
	     for(i=0;i<10;i++)
	      {
	       if(a[i]<a[i+1])
		{
		 temp=a[i];
		 a[i]=a[i+1];
		 a[i+1]=temp;
		}
	      }
	    }
	   printf("\n\n\t\t The Descending Order is:-\n");
	   for(i=0;i<10;i++)
	    {
	     printf("\n%d",a[i]);
	    }
	  break;

  case 3:
	  printf("\n\n\t Enter The element to be Searched:- ");
	  scanf("%d",&n);
	  for(i=0;i<10;i++)
	   {
	    if(a[i]==n)
	     {
	      m=1;
	      break;
	     }
	    else
	    m=0;

	   }
	 if(m==1)
	 printf("\n\n\t\t Element is Present. ");
	 else
	 printf("\n\n\t\t Element is Not Present. ");
	 break;

  case 4:
	  printf("\n\n\t Enter the Index of elements which you want to Swap:- ");
	  scanf("%d %d",&n,&m);
	  temp=a[n];
	  a[n]=a[m];
	  a[m]=temp;
	  printf("\n\n\t\t The New Order of elements is:- ");
	  for(i=0;i<10;i++)
	  printf("\n%d",a[i]);
	  break;

  case 5:
	  max=a[0];
	  for(i=0;i<10;i++)
	   {
	    if(a[i]>max)
	    max=a[i];
	   }
	  printf("\n\n\t\tThe Maximum element is=%d ",max);
	  break;

  default:
	   printf("Wrong Choice.");

  }
 getch();
}




