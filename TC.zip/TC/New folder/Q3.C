/* For Printing 5*5 Matrix And Find it's Maximum Element And Find it's Collumn/Rows also*/

#include<stdio.h>
#include<conio.h>
 void main()
  {
   int a[5][5],i,j,max,r,c;
   clrscr();
   printf("\n enter the 5x5 matrix");
   for(i=1;i<=5;i++)
    {
      for(j=1;j<=5;j++)
       {
        scanf("  %d",&a[i][j]);
       }
    }
   printf("\n the matrix is\n ");
   for(i=1;i<=5;i++)
    {
     for(j=1;j<=5;j++)
      {
       printf("\t%d",a[i][j]);
      }
   printf("\n");

    }

   max=a[1][1];

   for(i=1;i<=5;i++)
    {
     for(j=1;j<=5;j++)
      {
       if(a[i][j]>max)
        {
         max=a[i][j];
         r=i;
         c=j;
        }
       }
    }

   printf("\n the maximum element is %d ",max);
   printf("\n the row is %d and the column is %d ",r,c);
  getch();
 }