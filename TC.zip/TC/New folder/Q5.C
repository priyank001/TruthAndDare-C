#include<stdio.h>
#include<conio.h>
#include<string.h>
void rev(char str[20]);
void upp(char str[20]);

void  main()
{
int i,j,ch;
char str[20];
clrscr();
printf("\n enter the string ");
gets(str);
printf("\n 1. reverse string\n 2. upper copy\n 3. compare \n enter choice");
scanf("%d",&ch);
if(ch==1)
{
rev(str);
}
else if(ch==2)
{
upp(str);
}
/*else if(ch==3)
{
com(str);
} */
getch();
}

void rev(char str[20])
{
int i,len;
char s;
len=strlen(str);
for(i=len-1;i>=0;i--)
{
   printf("%c",str[i]);
}
}

void upp(char str[20])
{
int i,len;
len=strlen(str);
for(i=0;i<len;i++)
{
str[i]=toupper(str[i]);
printf("%c",str[i]);
}
}

