#include<stdio.h>
#include<conio.h>
 void main()
 {
  int a[5][75],i,j;
  clrscr();
  printf("\n enter the 5x5 elements ");
  for(i=0;i<5;i++)
   {
    for(j=0;j<5;j++)
     {
      scanf("%d",&a[i][j]);
     }
    printf("\n");
   }

  printf("\n the matrix is \n");
  for(i=0;i<5;i++)
   {
    for(j=0;j<5;j++)
     {
      printf("\t%d",a[i][j]);
     }
    printf("\n");
   }

  for(i=0;i<5;i++)
   {
    for(j=0;j<5;j++)
    {
     if(j>i)
      {
	  a[i][j]=a[i][j]+1;
      }
      else if(j<i)
      {
	  a[i][j]=a[i][j]-1;
      }
     }
    }

  printf("\n the updated matrix is \n");
  for(i=0;i<5;i++)
   {
    for(j=0;j<5;j++)
    {
     printf("\t%d",a[i][j]);
    }
  printf("\n");
  }

 getch();
}