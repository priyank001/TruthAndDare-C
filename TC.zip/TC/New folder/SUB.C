#include <stdio.h>
#include<conio.h>
#include <string.h>
void main()
{
    char sntnc[50], word[50], *ptr;
    int pos;
    clrscr();
    puts("\nEnter a sentence");
    gets(sntnc);

    puts("\nEnter a word");
    gets(word);

    ptr=strstr(sntnc,word);

    if(ptr=='\0')
    printf("\n could not find");
    else
    printf("The word starts at position %d" , ptr-sntnc+1);
    getch();
}